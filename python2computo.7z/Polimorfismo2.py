class Universidad:
    def __init__(self, nombre):
        self.nombre=nombre
clase1 = Universidad("en el cc2")
clase2 = Universidad("en el cc3")
class goku (Universidad):
    pass
    def resivirla():
        return"RESIVE LA CLASE {}".format(clase1.nombre)
    
class vegeta (Universidad):
    pass
    def resivirla():
        return"RESIVE LA CLASE {}".format(clase2.nombre)
ESTUDIANTE1 = goku  
ESTUDIANTE2 = vegeta
print ("alex ",ESTUDIANTE1.resivirla())
print ( "juan",ESTUDIANTE2.resivirla())