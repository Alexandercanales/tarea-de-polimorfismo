class JugarFutbol:
    def __init__(self, nombre):
        self.nombre=nombre
Partido1 = JugarFutbol("en el atlas")
Partido2 = JugarFutbol("en el barraza")
class alex (JugarFutbol):
    pass
    def partido():
        return"juega el partido {}".format(Partido1.nombre)
    
class juan (JugarFutbol):
    pass
    def partido():
        return"juega el partido {}".format(Partido2.nombre)
jugador1 = alex  
jugador2 = juan
print ("alex ",jugador1.partido())
print ( "juan",jugador2.partido())